const geoData = [
  {
    id: "AFG",
    value: 600,
  },
  {
    id: "AGO",
    value: 100,
  },
  {
    id: "ALB",
    value: 200,
  },
];

export default geoData;
