const data = [
  {
    agents: "DP World",
    dp_world: 100,
  },
  {
    agents: "Maresk",
    maersk: 70,
  },
  {
    agents: "Air Cargo",
    air_cargo: 90,
  },
  {
    agents: "Hv Clean",
    hvclean: 50,
  },
  {
    agents: "Real Logistics",
    real_logistics: 40,
  },
];
export default data;
