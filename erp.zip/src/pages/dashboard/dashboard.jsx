import React,{ useState } from "react";

function Dashboard () {
  
  return (
    <>
      <h2>Dashboard</h2>
      <div className="col-4">
        
      </div>
     
    </>
  );
};
export default Dashboard;








