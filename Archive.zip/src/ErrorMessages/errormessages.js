const ErrorMessages = {
  Unauthorized: "Unauthorized access",
  Decline:"Access denied"
};

module.exports = { ErrorMessages };
