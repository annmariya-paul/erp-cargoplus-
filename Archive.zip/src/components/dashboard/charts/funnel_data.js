const funnelData = [
  {
    id: "step_sent",
    value: 62818,
    label: "Sent",
  },
  {
    id: "step_viewed",
    value: 55564,
    label: "Viewed",
  },
  {
    id: "step_clicked",
    value: 40470,
    label: "Clicked",
  },
  {
    id: "step_add_to_card",
    value: 34506,
    label: "Add To Card",
  },
  {
    id: "step_purchased",
    value: 31892,
    label: "Purchased",
  },
];

export default funnelData;
