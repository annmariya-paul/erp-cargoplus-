// import React from 'react'
// import CustomModel from '../../../../components/custom_modal/custom_model'

// function OpportunityEdit() {
//   return (
//     <div>
//         <Custom_model >

//         </Custom_model>
//     </div>
//   )
// }

// export default OpportunityEdit
