function TestV1() {
  return (
    <div>
      <div>
        <label htmlFor="">V1 Input 1</label>
        <input type="text" />
      </div>
      <div>
        <label htmlFor="">V1 Input 2</label>
        <input type="text" />
      </div>
    </div>
  );
}

export default TestV1;
