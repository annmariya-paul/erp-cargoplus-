const pieData = [
  {
    id: "erlang",
    label: "erlang",
    value: 572,
    color: "hsl(130, 70%, 50%)",
  },
  {
    id: "java",
    label: "java",
    value: 236,
    color: "hsl(160, 70%, 50%)",
  },
  {
    id: "go",
    label: "go",
    value: 521,
    color: "hsl(30, 70%, 50%)",
  },
  {
    id: "lisp",
    label: "lisp",
    value: 535,
    color: "hsl(321, 70%, 50%)",
  },
  {
    id: "hack",
    label: "hack",
    value: 156,
    color: "hsl(139, 70%, 50%)",
  },
];

export default pieData;
