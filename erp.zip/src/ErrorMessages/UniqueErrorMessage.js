const UniqueErrorMsg = {
  UniqueErrName: " has already taken",
  // UniqueErrCode: "Code has already taken",
  // UniqueErrHSN: "HSN has already taken",
};

module.exports = { UniqueErrorMsg };
