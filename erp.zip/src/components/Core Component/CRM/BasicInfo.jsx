import React from "react";

function BasicInfo() {
  return <div>jhgdsjaibgudiefuye fuefieyfueifisdf yfefkhefye fkhfuit</div>;
}

export default BasicInfo;
